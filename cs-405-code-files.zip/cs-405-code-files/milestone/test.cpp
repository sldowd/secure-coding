// Uncomment the next line to use precompiled headers
//#include "pch.h"
// uncomment the next line if you do not use precompiled headers
#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
  ~Environment() override {}

  // Override this to define how to set up the environment.
  void SetUp() override
  {
    //  initialize random seed
    srand(time(nullptr));
  }

  // Override this to define how to tear down the environment.
  void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
  // create a smart point to hold our collection
  std::unique_ptr<std::vector<int>> collection;

  void SetUp() override
  { // create a new collection to be used in the test
    collection.reset( new std::vector<int>);
  }

  void TearDown() override
  { //  erase all elements in the collection, if any remain
    collection->clear();
    // free the pointer
    collection.reset(nullptr);
  }

  // helper function to add random values from 0 to 99 count times to the collection
  void add_entries(int count)
  {
    assert(count > 0);
    for (auto i = 0; i < count; ++i)
      collection->push_back(rand() % 100);
  }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
  // is the collection created
  ASSERT_TRUE(collection);

  // if empty, the size must be 0
  ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
  // is the collection empty?
  ASSERT_TRUE(collection->empty());

  // if empty, the size must be 0
  ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
TEST_F(CollectionTest, AlwaysFail)
{
  FAIL();
}

//  Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
  // is the collection empty?
  ASSERT_TRUE(collection->empty());

  // if empty, the size must be 0
  ASSERT_EQ(collection->size(), 0);

  add_entries(1);


  // is the collection still empty?
  ASSERT_FALSE(collection->empty());

  // the size must be 1
  ASSERT_EQ(collection->size(), 1);
}

//  Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
  add_entries(5);
  
  // collection should not be empty?
  ASSERT_FALSE(collection->empty());

  // the size should be 5 after adding 5 entries
  ASSERT_EQ(collection->size(), 5);
}

//  Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeGreaterThanOrEqualsSize)
{
  // 0 entries — check right after SetUp(), before adding anything
  ASSERT_GE(collection->max_size(), collection->size());

  // Loop clears collection, adds entries, verifies max size remains greater than or equal to size
  int counts[] = {1, 5, 10};
  for (int count : counts)
  {
    collection->clear();
    add_entries(count);
    ASSERT_GE(collection->max_size(), collection->size());
  }
}

//  Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityGreaterThanOrEqualsSize)
{
  // 0 entries — check right after SetUp(), before adding anything
  ASSERT_GE(collection->capacity(), collection->size());

  int counts[] = {1, 5, 10};
  for (int count : counts)
  {
    collection->clear();
    add_entries(count);
    ASSERT_GE(collection->capacity(), collection->size());
  }
}

//  Create a test to verify resizing increases the collection
TEST_F(CollectionTest, ResizeIncreasesCollection)
{
  add_entries(5);
  ASSERT_EQ(collection->size(), 5);

  collection->resize(10);
  ASSERT_EQ(collection->size(), 10);
}

//  Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, ResizeDecreasesCollection)
{
  add_entries(10);
  ASSERT_EQ(collection->size(), 10);

  collection->resize(5);
  ASSERT_EQ(collection->size(), 5);
}

// Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, ResizeDecreasesCollectionToZero)
{
  add_entries(10);
  ASSERT_EQ(collection->size(), 10);

  collection->resize(0);
  ASSERT_EQ(collection->size(), 0);
  ASSERT_TRUE(collection->empty());
}

//  Create a test to verify clear erases the collection
TEST_F(CollectionTest, VerifyClearEraseClearsCollection)
{
  // add 5 entries and verify size == 5
  add_entries(5);
  ASSERT_EQ(collection->size(), 5);
  // clear collection and verify size == 0 and collection is empty
  collection->clear();
  ASSERT_EQ(collection->size(), 0);
  ASSERT_TRUE(collection->empty());
}

//  Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, VerifyEraseErasesCollection)
{
  // add 5 entries and verify size == 5
  add_entries(5);
  ASSERT_EQ(collection->size(), 5);
  // erase collection using begin() and end() as starting and ending range iterators
  collection->erase(collection->begin(), collection->end());
  // verify result is collection where size == 0 and empty == true
  ASSERT_EQ(collection->size(), 0);
  ASSERT_TRUE(collection->empty());
}

//  Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, VerifyReserveIncreasesCapacityButNotSize)
{
  // add 5 entries and verify size == 5
  add_entries(5);
  ASSERT_EQ(collection->size(), 5);
  // reserve 1000 entries 
  collection->reserve(1000);
  // verify collection capacity is greater than or equal to 1000
  ASSERT_GE(collection->capacity(), 1000);
  // verify size is unchanged and still equals 5
  ASSERT_EQ(collection->size(), 5);
}

//  Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
TEST_F(CollectionTest, VerifyAtThrowOutOfRange)
{
  ASSERT_THROW(collection->at(100), std::out_of_range);
}

// Verify attempt to reserve more than max size throws std::length_error
TEST_F(CollectionTest, EnsureReserveThrowsLengthErrorWhenExceedingMaxSize)
{
  // reserving max_size() + 1 should throw length error exception
  ASSERT_THROW(collection->reserve(collection->max_size() + 1), std::length_error);
}

// Verify correctness of value at given index
TEST_F(CollectionTest, VerifyValueAtIndex)
{
  // add integer value at index 0 to collection
  collection->push_back(18);
  // verify value at index 0 == value added
  ASSERT_EQ(collection->at(0), 18);
}
