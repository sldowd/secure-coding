#!/bin/bash
set -e  # exit immediately if any command fails, instead of continuing on with a broken build

g++ test.cpp -std=c++17 -lgtest -lgtest_main -pthread -o test

echo "Build succeeded -> ./test"