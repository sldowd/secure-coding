// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <limits>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
  //  even though it is a constant and the compiler buffer overflow checks are on.
  //  You need to modify this method to prevent buffer overflow without changing the account_number
  //  variable, and its position in the declaration. It must always be directly before the variable used for input.
  //  You must notify the user if they entered too much data.

  const std::string account_number = "CharlieBrown42";
  char user_input[20];
  std::cout << "Enter a value: ";
  // Added cin's getline() method to cap the size of written input to the size of the user_input arr
  //regardless of how many characters are typed, only the first 19 will be written (20th byte reserved for null terminator)
  std::cin.getline(user_input, sizeof(user_input));

  // Check for failbit on stream, alert user to overflow
  if (std::cin.fail())
  {
    std::cout << "Error: input exceeded buffer size. Only the first 19 characters were accepted." << std::endl;
    std::cin.clear(); // reset the failbit so the stream is usable again
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // discard the rest of the overlong line
  }
  
  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
