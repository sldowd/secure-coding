// SQLInjection.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <algorithm>
#include <iostream>
#include <locale>
#include <tuple>
#include <vector>
#include <regex> // use std::regex to scan query before passing to database

#include "sqlite3.h"

// DO NOT CHANGE
typedef std::tuple<std::string, std::string, std::string> user_record;
const std::string str_where = " where ";

// DO NOT CHANGE
static int callback(void* possible_vector, int argc, char** argv, char** azColName)
{
  if (possible_vector == NULL)
  { // no vector passed in, so just display the results
    for (int i = 0; i < argc; i++) 
    {
      std::cout << azColName[i] << " = " << (argv[i] ? argv[i] : "NULL") << std::endl;
    }
    std::cout << std::endl;
  }
  else
  {
    std::vector< user_record >* rows =
      static_cast<std::vector< user_record > *>(possible_vector);

    rows->push_back(std::make_tuple(argv[0], argv[1], argv[2]));
  }
  return 0;
}

// DO NOT CHANGE
bool initialize_database(sqlite3* db)
{
  char* error_message = NULL;
  std::string sql = "CREATE TABLE USERS(" \
    "ID INT PRIMARY KEY     NOT NULL," \
    "NAME           TEXT    NOT NULL," \
    "PASSWORD       TEXT    NOT NULL);";

  int result = sqlite3_exec(db, sql.c_str(), callback, NULL, &error_message);
  if (result != SQLITE_OK)
  {
    std::cout << "Failed to create USERS table. ERROR = " << error_message << std::endl;
    sqlite3_free(error_message);
    return false;
  }
  std::cout << "USERS table created." << std::endl;

  // insert some dummy data
  sql = "INSERT INTO USERS (ID, NAME, PASSWORD)" \
    "VALUES (1, 'Fred', 'Flinstone');" \
    "INSERT INTO USERS (ID, NAME, PASSWORD)" \
    "VALUES (2, 'Barney', 'Rubble');" \
    "INSERT INTO USERS (ID, NAME, PASSWORD)" \
    "VALUES (3, 'Wilma', 'Flinstone');" \
    "INSERT INTO USERS (ID, NAME, PASSWORD)" \
    "VALUES (4, 'Betty', 'Rubble');";

  result = sqlite3_exec(db, sql.c_str(), callback, NULL, &error_message);
  if (result != SQLITE_OK)
  {
    std::cout << "Data failed to insert to USERS table. ERROR = " << error_message << std::endl;
    sqlite3_free(error_message);
    return false;
  }

  return true;
}

bool run_query(sqlite3* db, const std::string& sql, std::vector< user_record >& records)
{
  // Detects tautology injection of the form "OR <literal> = <same literal>",
  // where <literal> is a quoted string or a numeric value.
  // static const: compiled once on first call, not on every query.
  // Pattern breakdown:
  //   \bor\b[\s(]*   the word OR, then any spaces or opening parens
  //   (...)          capture group 1: the left-hand literal, one of:
  //     '[^']*'          single-quoted string (may be empty)
  //     "[^"]*"          double-quoted string (SQLite accepts these)
  //     [+-]?[0-9]*\.?[0-9]+   number with optional sign and decimal
  //     \w+              bare word (e.g. 0x1, 1e0, a column name)
  //   \s*=\s*        equals sign with optional whitespace
  //   \1             back-reference: right side must equal the left side
  //   (?![\w.])      not followed by more literal characters, so
  //                  "or 1=10" is not flagged
  // std::regex::icase makes matching case-insensitive (OR, or, Or).
  static const std::regex tautology_pattern(
    R"rx(\bor\b[\s(]*('[^']*'|"[^"]*"|[+-]?[0-9]*\.?[0-9]+|\w+)\s*=\s*\1(?![\w.]))rx",
    std::regex::icase);

  
  if (std::regex_search(sql, tautology_pattern))
  {
    // On pattern detection print warning and blocked query string, return false
    std::cout << "!! Warning: SQL Injection Attack Detected! Query blocked: " << sql << std::endl;
    return false;
  }

  // clear any prior results
  records.clear();

  char* error_message;
  if(sqlite3_exec(db, sql.c_str(), callback, &records, &error_message) != SQLITE_OK)
  {
    std::cout << "Data failed to be queried from USERS table. ERROR = " << error_message << std::endl;
    sqlite3_free(error_message);
    return false;
  }

  return true;
}

// DO NOT CHANGE
bool run_query_injection(sqlite3* db, const std::string& sql, std::vector< user_record >& records)
{
  std::string injectedSQL(sql);
  std::string localCopy(sql);

  // we work on the local copy because of the const
  std::transform(localCopy.begin(), localCopy.end(), localCopy.begin(), ::tolower);
  if(localCopy.find_last_of(str_where) >= 0)
  { // this sql has a where clause
    if(localCopy.back() == ';')
    { // smart SQL developer terminated with a semicolon - we can fix that!
      injectedSQL.pop_back();
    }

    switch (rand() % 4)
    {
    case 1:
      injectedSQL.append(" or 2=2;");
      break;
    case 2:
      injectedSQL.append(" or 'hi'='hi';");
      break;
    case 3:
      injectedSQL.append(" or 'hack'='hack';");
      break;
    case 0:
    default:
      injectedSQL.append(" or 1=1;");
      break;
    }
  }
  
  return run_query(db, injectedSQL, records);
}


// DO NOT CHANGE
void dump_results(const std::string& sql, const std::vector< user_record >& records)
{
  std::cout << std::endl << "SQL: " << sql << " ==> " << records.size() << " records found." << std::endl;

  for (auto record : records)
  {
    std::cout << "User: " << std::get<1>(record) << " [UID=" << std::get<0>(record) << " PWD=" << std::get<2>(record) << "]" << std::endl;
  }
}

// DO NOT CHANGE
void run_queries(sqlite3* db)
{
  char* error_message = NULL;

  std::vector< user_record > records;

  // query all
  std::string sql = "SELECT * from USERS";
  if (!run_query(db, sql, records)) return;
  dump_results(sql, records);

  //  query 1
  sql = "SELECT ID, NAME, PASSWORD FROM USERS WHERE NAME='Fred'";
  if (!run_query(db, sql, records)) return;
  dump_results(sql, records);

  //  run query 1 with injection 5 times
  for (auto i = 0; i < 5; ++i)
  {
    if (!run_query_injection(db, sql, records)) continue;
    dump_results(sql, records);
  }

}

// You can change main by adding stuff to it, but all of the existing code must remain, and be in the
// in the order called, and with none of this existing code placed into conditional statements
int main()
{
  // initialize random seed:
  srand(time(nullptr));

  int return_code = 0;
  std::cout << "SQL Injection Example" << std::endl;

  // the database handle
  sqlite3* db = NULL;
  char* error_message = NULL;

  // open the database connection
  int result = sqlite3_open(":memory:", &db);

  if(result != SQLITE_OK)
  {
    std::cout << "Failed to connect to the database and terminating. ERROR=" << sqlite3_errmsg(db) << std::endl;
    return -1;
  }

  std::cout << "Connected to the database." << std::endl;

  // initialize our database
  if(!initialize_database(db))
  {
    std::cout << "Database Initialization Failed. Terminating." << std::endl;
    return_code = -1;
  }
  else
  {
    run_queries(db);

    // ADDED: table-driven tests for run_query() - each case is a query plus
    // whether the injection filter should block it.
    struct test_case
    {
      std::string description;
      std::string query;
      bool expect_blocked;
    };

    const std::string base = "SELECT ID, NAME, PASSWORD FROM USERS WHERE NAME='Fred'";
    const std::vector<test_case> tests = 
    {
      // attacks that must be blocked
      { "numeric tautology", base + " or 1=1",true  },
      { "spaces around equals",base + " OR 7 = 7", true  },
      { "decimal tautology", base + " or 1.5=1.5",true  },
      { "negative number tautology",base + " or -1=-1", true  },
      { "quoted string tautology",base + " or 'hi'='hi'",  true  },
      { "empty string tautology", base + " or ''=''", true },
      { "no space after OR", base + " or'a'='a'", true },
      { "parenthesized tautology",base + " or (1=1)", true  },
      { "double-quoted tautology",base + " or \"a\"=\"a\"", true },
      // legitimate queries that must be allowed
      { "legitimate OR, same column", base + " OR NAME='Barney'", false },
      { "legitimate OR, two columns", base + " OR ID=3", false },
      { "non-tautology comparison", base + " or 1=10", false },
      { "ORDER BY is not an OR", base + " ORDER BY ID", false }
    };

    std::cout << "\n********** Begin Injection Filter Tests **********" << std::endl;
    int failures = 0;
    for (const auto& t : tests)
    {
      std::vector<user_record> test_records;
      bool blocked = !run_query(db, t.query, test_records);
      bool passed = (blocked == t.expect_blocked);
      if (!passed) ++failures;
      std::cout << (passed ? "PASS: " : "FAIL: ") << t.description
                << " (expected " << (t.expect_blocked ? "blocked" : "allowed")
                << ", got " << (blocked ? "blocked" : "allowed") << ")" << std::endl;
    }
    std::cout << (failures == 0 ? "All tests passed." : "Some tests FAILED.") << std::endl;
  }

  // close the connection if opened
  if(db != NULL)
  {
    sqlite3_close(db);
  }

  return return_code;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
