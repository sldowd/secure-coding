// unit_tests.cpp
#include <gtest/gtest.h>
#include "sqlite3.h"

// Pull in the original code and rename its main() so Google Test's main runs.
// SQLInjection.cpp itself is not modified.
#define main sqli_main
#include "SQLInjection.cpp"
#undef main

// Fixture: a fresh in-memory database with the USERS table for every test,
// like CollectionTest in test.cpp.
class InjectionFixture : public ::testing::Test {
protected:
  sqlite3* db = nullptr;

  void SetUp() override {
    ASSERT_EQ(sqlite3_open(":memory:", &db), SQLITE_OK);
    ASSERT_TRUE(initialize_database(db));
  }

  void TearDown() override {
    sqlite3_close(db);
  }
};

bool authenticate_parameterized(sqlite3* db, const std::string& username, const std::string& password) {
    const char* sql = "SELECT * FROM USERS WHERE NAME = ? AND PASSWORD = ?;";
    sqlite3_stmt* statement = nullptr;

    if (sqlite3_prepare_v2(db, sql, -1, &statement, nullptr) != SQLITE_OK) {
        std::cout << "Failed to prepare statement." << std::endl;
        return false;
    }

    sqlite3_bind_text(statement, 1, username.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(statement, 2, password.c_str(), -1, SQLITE_TRANSIENT);

    bool authenticated = (sqlite3_step(statement) == SQLITE_ROW);
    sqlite3_finalize(statement);
    return authenticated;
}


// Positive: a legitimate query returns the matching row.
TEST_F(InjectionFixture, AllowsLegitimateNameQuery) {
  std::vector<user_record> rows;
  EXPECT_TRUE(run_query(db,
      "SELECT ID, NAME, PASSWORD FROM USERS WHERE NAME='Fred'", rows));
  ASSERT_EQ(rows.size(), 1u);
}

// Negative: a tautology injected after the WHERE clause is blocked.
TEST_F(InjectionFixture, BlocksNumericTautology) {
  std::vector<user_record> rows;
  EXPECT_FALSE(run_query(db,
      "SELECT ID, NAME, PASSWORD FROM USERS WHERE NAME='Fred' or 1=1", rows));
}

// Negative: a quoted-string tautology is blocked.
TEST_F(InjectionFixture, BlocksQuotedStringTautology) {
  std::vector<user_record> rows;
  EXPECT_FALSE(run_query(db,
      "SELECT ID, NAME, PASSWORD FROM USERS WHERE NAME='Fred' or 'hi'='hi'", rows));
}

// Negative, on the parameterized version: the same payload is treated as
// data, so no row matches.
TEST_F(InjectionFixture, ParameterizedQueryTreatsPayloadAsData) {
  EXPECT_FALSE(authenticate_parameterized(db, "Fred' or 1=1 --", "x"));
}