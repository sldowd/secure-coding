#!/bin/bash
set -e  # exit immediately if any command fails, instead of continuing on with a broken build

gcc -c sqlite3.c -o sqlite3.o
g++ -c SQLInjection.cpp -o SQLInjection.o
g++ sqlite3.o SQLInjection.o -o sqlinjection -ldl -lpthread
g++ -std=c++17 unit_tests.cpp -I"$(brew --prefix)/include" -L"$(brew --prefix)/lib" -lgtest -lgtest_main -pthread -lsqlite3 -o unit_tests
./unit_tests

echo "Build succeeded -> ./sqlinjection"
